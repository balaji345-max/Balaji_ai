#include <bits/stdc++.h>
#define ll long long
using namespace std;
string cy(const string& a) {
    ll n = a.size();
    string b;
    b.resize(n);
    for (ll i = 0; i < n; i++) {
        b[i] = a[(i + 1) % n];
    }
    return b;
}
string _xor(const string& a, const string& b) {
    string q;
    ll n = a.size();
    for (ll i = 0; i < n; i++) {
        q += (a[i] == b[i]) ? '0' : '1';
    }
    return q;
}

int main() {
    string a, b; // a - key (12 bits), b - cipher/plaintext (8 bits)
    cin >> a >> b;

    string sh1, sh2;
    sh1.resize(8);
    sh2.resize(8);

    vector<string> c(3), d(3);

    string k1, k2;
    k1.resize(8);
    k2.resize(8);

    ll dp[] = {2, 5, 1, 3, 8, 4, 7, 6};
    ll dp1[] = {2, 0, 3, 5, 1, 7, 6, 4};
    ll dp2[] = {9, 3, 0, 4, 10};
    ll dp3[] = {7, 8, 2, 6, 1};
    ll dp4[] = {7, 1, 3, 8, 6, 9, 5, 2};
// step1: permutate as give in que.
for (ll i = 0; i < 8; i++) {
        sh1[i] = b[dp[i] - 1];
    }
  //as per table 7.2 in que:
  // left half c0 and right half d[0]( we are permutating as per table)
  for (ll i = 0; i < 5; i++) {
        c[0] += a[dp2[i]];
        d[0] += a[dp3[i]];
    }
   for (ll i = 0; i < 2; i++) {
        c[i + 1] = cy(c[i]); // cyclic shift
        d[i + 1] = cy(d[i]);// cycli shift
        string y = c[i + 1] + d[i + 1];
        for (ll j = 0; j < 8; j++) {
            if (i == 0) {
                k1[j] = y[dp4[j]];
            } else {
                k2[j] = y[dp4[j]];
            }
        }
    }
    // keys are ready for two rounds;
    // similar to fiestel  now.
    string q = _xor(k1, sh1);
    q = _xor(k2, q);
    for (ll i = 0; i < 8; i++) {
        sh2[i] = q[dp1[i]];
    }
    cout <<sh2<< endl;
    /*cout << c[0]<< endl;
    cout << d[0]<< endl;
    cout << c[1]<< endl;
    cout << d[1]<< endl;
    cout << c[2]<< endl; 
    cout << d[2]<< endl;*/
    

    return 0;
}
