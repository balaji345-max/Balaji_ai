#include <bits/stdc++.h>
#define ll long long
using namespace std;
string cy(const string& a) {
    ll n = a.size();
    string b;
    b.resize(n);
    for (ll i = 0; i < n; i++) {
        b[i] = a[(i+1) % n];
    }
    return b;
}
string _xor(const string& a, const string& b) {
    string q;
    ll n = a.size();
    for (ll i = 0; i < n; i++) {
        q += (a[i] == b[i]) ? '0' : '1';
    }
    return q;
}

int main() {
    string a, b; // a - key (12 bits), b - cipher/plaintext (8 bits)
    cin >> a >> b;
    string sh1, sh2;
    sh1.resize(8);
    sh2.resize(8);
    vector<string> c(3), d(3);
    string k1, k2;
    k1.resize(8);
    k2.resize(8);
    ll dp[] = {3,1,4,6,2,8,7,5};
    ll dp1[] = {1,4,0,2,7,3,6,5};
    ll dp2[] = {9, 3, 0, 4, 10};
    ll dp3[] = {7, 8, 2, 6, 1};
    ll dp4[] = {7, 1, 3, 8, 6, 9, 5, 2};
  //as per table 7.2 in que:
  // left half c0 and right half d[0]( we are permutating as per table)
  for (ll i = 0; i < 5; i++) {
        c[0] += a[dp2[i]];
        d[0] += a[dp3[i]];
    }
   for (ll i = 0; i < 2; i++) {
        c[i + 1] = cy(c[i]); // cyclic shift
        d[i + 1] = cy(d[i]);// cycli shift
        string y = c[i + 1] + d[i + 1];
        for (ll j = 0; j < 8; j++) {
            if (i == 0) {
                k1[j] = y[dp4[j]];
            } else {
                k2[j] = y[dp4[j]];
            }
        }
    }
    // keys are ready for two rounds;
    //we should use in reverse order for decryption.
    for(ll i=0;i<8;i++){
       sh1[i]=b[dp1[i]];
    }
    sh1=_xor(sh1,k2);
    sh1=_xor(sh1,k1);
   for(ll i=0;i<8;i++){
     sh2[i]=sh1[dp[i]-1];
   }
    cout<<sh2<<endl;
    return 0;
}