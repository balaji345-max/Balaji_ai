#include <bits/stdc++.h>
#define ll long long
#define f(i, a, b) for (ll i = a; i < b; i++)
using namespace std;
string bin_6(ll n) {
    string u(6, '0');
    f(i, 0, 6) {
        if (n & (1LL << i)) {
            u[5 - i] = '1';
        }
    }
    return u;
}

string bin_4(ll n) {
    string u(4, '0');
    f(i, 0, 4) {
        if (n & (1LL << i)) {
            u[3 - i] = '1';
        }
    }
    return u;
}

ll bin_n4(const string& a) {
    ll ans = 0LL;
    f(i, 0, 4) {
        ans += (1LL << (3 - i)) * (a[i] - '0');
    }
    return ans;}
string bin_hex(const string &b){
  string y;
  f(i,0,b.size()/4){
    string g=b.substr(i*4,4);
    ll val=bin_n4(g);
    if(val<10){y+=(val+'0');}
    else{y+=('A'+(val-10));}
  }
  return y;
}
string hex_bin(const string &s){
  string p;
  f(i,0,s.size()){
    if(isdigit(s[i])){ p+=bin_4(s[i]-'0');}
    else{ll val=s[i]-'A'+10; p+=bin_4(val);}
  } return p;
}
string _xor(const string& a, const string& b) {
    string u(a.size(), '0');
    f(i, 0, a.size()) {
        u[i] = (a[i] == b[i]) ? '0' : '1';
    }
    return u;
}
// inner structure (6 rounds)
string FUN(const string& q, const vector<string>& box) {
    vector<string> p(7);
    p[0] = q;
    string a, b, c, d, a1, b1, c1, d1;
    f(i, 1, 7) {
        a = p[i - 1].substr(0, 4);
        b = p[i - 1].substr(4, 4);
        c = p[i - 1].substr(8, 4);
        d = p[i - 1].substr(12, 4);
        a1 = _xor(b, box[bin_n4(a)]);
        b1 = c;
        c1 = _xor(d, box[bin_n4(c)]);
        d1 = a;
        p[i] = a1 + b1 + c1 + d1;
    }
   /* string p1;
    p1 += p[6].substr(4, 4); //2
    p1 += p[6].substr(8, 4); // 3
    p1 += p[6].substr(12, 4); // 4
    p1 += p[6].substr(0, 4); // 1*/
    return p[6];
}

int main() {
    string s1, tx1,s,tx;
    cin >> tx1 >> s1;
    s=hex_bin(s1);
    tx=hex_bin(tx1);
    vector<string> rk(36, ""); 
    vector<string> rc(36, ""); 
    vector<string> k(5);      
    for (ll i = 0; i < 80; i++) {
        if (i < 16) {
            k[0] += s[i];
        } else if (i >= 16 && i < 32) {
            k[1] += s[i];
        } else if (i >= 32 && i < 48) {
            k[2] += s[i];
        } else if (i >= 48 && i < 64) {
            k[3] += s[i];
        } else {
            k[4] += s[i];
        }
    }
    for (ll i = 0; i < 36; i++) {
        rc[i] = '0' + bin_6(i) + "00" + bin_6(i) + '0';
    }
    for (ll i = 0; i < 36; i++) {
        rk[i] = _xor(k[i % 5], rc[i]);
    }
    vector<string> box(16);
    box[0] = bin_4(12);
    box[1] = bin_4(5);
    box[2] = bin_4(6);
    box[3] = bin_4(11);
    box[4] = bin_4(9);
    box[5] = bin_4(0);
    box[6] = bin_4(10);
    box[7] = bin_4(13);
    box[8] = bin_4(3);
    box[9] = bin_4(14);
    box[10] = bin_4(15);
    box[11] = bin_4(8);
    box[12] = bin_4(4);
    box[13] = bin_4(7);
    box[14] = bin_4(1);
    box[15] = bin_4(2);

    vector<string> p(19);  
    p[0] = tx;
    f(i, 1, 19) {
        string l = p[i - 1];
        string a, b, c, d, a1, b1, c1, d1;
        a = l.substr(0, 16);
        b = l.substr(16, 16);
        c = l.substr(32, 16);
        d = l.substr(48, 16);
     // whitening keys are used before outer structures. 
        if(i==1){
          a=_xor(a,k[0]);
          c=_xor(c,k[1]);
        }
        a1 = _xor(b, FUN(a, box));
        a1 = _xor(a1, rk[2 * (i - 1)]);
        b1 = c;
        d1 = a;
        c1 = _xor(d, FUN(c, box));
        c1 = _xor(c1, rk[2 * i - 1]);
        p[i] = a1 + b1 + c1 + d1;
    }
   string h1;
  h1+=p[18].substr(0,16);
  h1+=_xor(p[18].substr(16,16),k[4]);
  h1+=p[18].substr(32,16);
  h1+=_xor(p[18].substr(48,16),k[3]);
  h1=bin_hex(h1);
  cout<<h1<<endl;
    return 0;
}