#include <bits/stdc++.h>
#define ll long long
#define f(i, a, b) for (ll i = a; i < b; i++)
using namespace std;

string bin_4(ll n) {
    string u(4, '0');
    f(i, 0, 4) {
        if (n & (1LL << i)) {
            u[3 - i] = '1';
        }
    }
    return u;
}

int main() {
    vector<string> box = {
        bin_4(12), bin_4(5), bin_4(6), bin_4(11),
        bin_4(9), bin_4(0), bin_4(10), bin_4(13),
        bin_4(3), bin_4(14), bin_4(15), bin_4(8),
        bin_4(4), bin_4(7), bin_4(1), bin_4(2)
    };

    vector<vector<ll>> dp(16, vector<ll>(16, 0));

    for (ll a = 0; a <16; a++) {
        string p = bin_4(a);
        for (ll b = 0; b < 16; b++) {
            string q = bin_4(b);
            ll ans = 0LL;
            for (ll x = 0; x < 16; x++) {
                string we = bin_4(x);
                string y = box[x];
                ll f1 = 0, f2 = 0;
                for (ll i = 0; i < 4; i++) {
                 if(we[i]==p[i] && p[i]=='1') f1++;
                }
                for (ll i = 0; i < 4; i++) {
                    if(q[i]==y[i] && y[i]=='1') f2++;
                }
                if (f1%2 == f2%2) ans++;
            }
            dp[a][b] = ans;
        }
    }
    for (ll i = 0; i <16; i++) {
        for (ll j = 0; j <16; j++) {
            cout << dp[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
