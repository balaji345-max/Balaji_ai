#include <bits/stdc++.h>
#define ll long long
using namespace std;
string bin(ll n) {
    if (n == 0) return "0";
    string v;
    while (n > 0) {
        v += (n % 2) ? '1' : '0';
        n /= 2;
    }
    reverse(v.begin(), v.end()); 
    return v;
}
string b2h(const string& b) {
    string h;
    for (size_t i = 0; i < b.size(); i += 4) {
        int d = 0;
        for (size_t j = 0; j < 4 && i + j < b.size(); ++j) {
            d = (d << 1) | (b[i + j] - '0');
        }
        h += (d < 10) ? to_string(d) : string(1, 'A' + (d - 10));
    }
    return h;
}
string _xor(const string& a, const string& b) {
    string q;
    ll n = a.size();
    for (ll i = 0; i < n; i++) {
        q += (a[i] == b[i]) ? '0' : '1';
    }
    return q;
}
int main() {
    string key, code;
   // ll rounds;
    cin >> key >> code;
    // key is 12 bit as per que
    // plain text code is 8
    
    string a1, a2;
    for (char c : key) {
        if (isdigit(c)) {
            string u = bin(c - '0');
            a1 += u;
        } else {
            ll w = c - 'A' + 10;
            string h = bin(w);
            a1 += h;
        }
    }

    for (char c : code) {
        if (isdigit(c)) {
            string u = bin(c - '0');
            a2 += u;
        } else {
            ll w = c - 'A' + 10;
            string h = bin(w);
            a2 += h;
        }
    }
    ll rounds=3;// given in  que
     vector<string>L(rounds+1),R(rounds+1);
    ll y = a1.size() / rounds;
    vector<string> roundKeys(rounds);
    for (ll i = 0; i < rounds; i++) {
        string f = a1.substr(i * y, y);
        string q;
        if((i+1)*y<a1.size()){
       q = a1.substr((i + 1) * y, y);}
        else{
         q=a1.substr(0,y);
        } 
        roundKeys[i] = _xor(f, q);
    }
    L[0] = a2.substr(0, a2.size() / 2);
    R[0]= a2.substr(a2.size() / 2);
    for(ll i=1;i<=rounds;i++){
      L[i]=R[i-1];
      R[i]=_xor(L[i-1],_xor(roundKeys[i-1],R[i-1]));
    }
  string ans=R[rounds]+L[rounds];
  cout<<"binary:"<<" "<<ans<<endl;
  cout<<"hexa_decimal:"<<" "<<b2h(ans)<<endl;
    return 0;
}
