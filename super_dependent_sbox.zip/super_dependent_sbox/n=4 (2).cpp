#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#define ll long long

ll idx(const vector<bool>& bits) {
    ll index = 0;
    for (bool bit : bits) {
        index = (index << 1) | bit;
    }
    return index;
}

bool is_dep(const vector<bool>& f_outs, ll var_idx) {
    for (ll b1 = 0; b1 < 2; ++b1) {
        for (ll b2 = 0; b2 < 2; ++b2) {
            for (ll b3 = 0; b3 < 2; ++b3) {
                for (ll b4 = 0; b4 < 2; ++b4) {
                    vector<bool> in0 = {b1, b2, b3, b4};
                    vector<bool> in1 = in0;
                    in0[var_idx] = 0;
                    in1[var_idx] = 1;

                    if (f_outs[idx(in0)] != f_outs[idx(in1)]) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

bool check_dep(const vector<vector<bool>>& perm) {
    vector<bool> f1, f2, f3, f4;
    for (const auto& p : perm) {
        f1.push_back(p[0]);
        f2.push_back(p[1]);
        f3.push_back(p[2]);
        f4.push_back(p[3]);
    }

    return is_dep(f1, 0) && is_dep(f1, 1) && is_dep(f1, 2) && is_dep(f1, 3) &&
           is_dep(f2, 0) && is_dep(f2, 1) && is_dep(f2, 2) && is_dep(f2, 3) &&
           is_dep(f3, 0) && is_dep(f3, 1) && is_dep(f3, 2) && is_dep(f3, 3) &&
           is_dep(f4, 0) && is_dep(f4, 1) && is_dep(f4, 2) && is_dep(f4, 3);
}

void find_s_boxes() {
    vector<vector<bool>> inputs = {
        {0, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, {0, 0, 1, 1},
        {0, 1, 0, 0}, {0, 1, 0, 1}, {0, 1, 1, 0}, {0, 1, 1, 1},
        {1, 0, 0, 0}, {1, 0, 0, 1}, {1, 0, 1, 0}, {1, 0, 1, 1},
        {1, 1, 0, 0}, {1, 1, 0, 1}, {1, 1, 1, 0}, {1, 1, 1, 1}
    };
    ll count = 0;

    do {
        vector<vector<bool>> perm(inputs);
        if (check_dep(perm)) {
            count++;
        }
    } while (next_permutation(inputs.begin(), inputs.end()));

    cout << "\nTotal number of super-dependent S-boxes for n=4: " << count << endl;
    // for n=4 by brute force method it is very large number compiler cant run as O(16!)
    //S(4)=19344102217728 
    // as n increases = s(n) tends to infinity.
}

int main() {
    find_s_boxes();
    return 0;
}
