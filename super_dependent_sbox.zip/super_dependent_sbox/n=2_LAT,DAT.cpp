#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <tuple>
#define ll long long
using namespace std;
bool dep_on_var(map<vector<ll>,ll> &f_outputs,ll idx) {
    for (ll b1 = 0; b1 <= 1; ++b1) {
        for (ll b2 = 0; b2 <= 1; ++b2) {
            vector<ll> in0 = {b1, b2}, in1 = {b1, b2};
            in0[idx] = 0;
            in1[idx] = 1;
            if (f_outputs[in0] != f_outputs[in1]) {
                return true;
            }
        }
    }
    return false;
}

bool check_super_dep(map<vector<ll>, vector<ll>> &perm) {
    map<vector<ll>, ll> f1_out, f2_out;
    for (auto &[k, v] : perm) {
        f1_out[k] = v[0];
        f2_out[k] = v[1];
    }
    return dep_on_var(f1_out, 0) && dep_on_var(f1_out, 1) &&
           dep_on_var(f2_out, 0) && dep_on_var(f2_out, 1);
}

int find_super_dep_sboxes() {
    vector<vector<ll>> in = {{0, 0}, {0, 1}, {1, 0}, {1, 1}};
  ll count = 0;

    do {
        map<vector<ll>, vector<ll>> perm;
        for (ll i = 0; i < 4; ++i) {
            perm[in[i]] = in[(i + 1) % 4];
        }
        if (check_super_dep(perm)) {
            ++count;
            cout << "Super-dependent S-box found: ";
            for (auto &[k, v] : perm) {
                cout << "{" << k[0] << ", " << k[1] << "} -> {" << v[0] << ", " << v[1] << "} ";
            }
            cout << endl;
        }
    } while (next_permutation(in.begin(), in.end()));

    return count;
}

int main() {
    int result = find_super_dep_sboxes();
    cout << "Number of super-dependent S-boxes for n=2: " << result << endl;
    return 0;
}