#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;
#define ll long long

ll idx(const vector<bool>& bits) {
    ll index = 0;
    for (bool bit : bits) {
        index = (index << 1) | bit;
    }
    return index;
}

string bin_4(ll n) {
    string u(4, '0');
    for (ll i = 0; i < 4; i++) {
        if (n & (1LL << i)) {
            u[3 - i] = '1';
        }
    }
    return u;
}

bool is_dep(const vector<bool>& f_outs, int var_idx) {
    for (int b1 = 0; b1 < 2; ++b1) {
        for (int b2 = 0; b2 < 2; ++b2) {
            for (int b3 = 0; b3 < 2; ++b3) {
                for (int b4 = 0; b4 < 2; ++b4) {
                    vector<bool> in0 = {static_cast<bool>(b1), static_cast<bool>(b2), static_cast<bool>(b3), static_cast<bool>(b4)};
                    vector<bool> in1 = in0;
                    in0[var_idx] = false;
                    in1[var_idx] = true;

                    if (f_outs[idx(in0)] != f_outs[idx(in1)]) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

bool check_dep(const vector<vector<bool>>& perm) {
    vector<bool> f1, f2, f3, f4;
    for (const auto& p : perm) {
        f1.push_back(p[0]);
        f2.push_back(p[1]);
        f3.push_back(p[2]);
        f4.push_back(p[3]);
    }
    return is_dep(f1, 0) && is_dep(f1, 1) && is_dep(f1, 2) && is_dep(f1, 3) &&
           is_dep(f2, 0) && is_dep(f2, 1) && is_dep(f2, 2) && is_dep(f2, 3) &&
           is_dep(f3, 0) && is_dep(f3, 1) && is_dep(f3, 2) && is_dep(f3, 3) &&
           is_dep(f4, 0) && is_dep(f4, 1) && is_dep(f4, 2) && is_dep(f4, 3);
}

vector<vector<ll>> compute_LAT(const vector<vector<bool>>& s_box) {
    vector<vector<ll>> dp(16, vector<ll>(16, 0));

    for (ll a = 0; a < 16; a++) {
        string p = bin_4(a);
        for (ll b = 0; b < 16; b++) {
            string q = bin_4(b);
            ll ans = 0;

            for (ll x = 0; x < 16; x++) {
                string we = bin_4(x);
                string y;
                for (ll i = 0; i < 4; i++) {
                    y += (s_box[x][i] ? '1' : '0');
                }

                ll f1 = 0, f2 = 0;
                for (ll i = 0; i < 4; i++) {
                    if (we[i] == p[i] && p[i] == '1') f1++;
                }
                for (ll i = 0; i < 4; i++) {
                    if (y[i] == q[i] && q[i] == '1') f2++;
                }

                if (f1 % 2 == f2 % 2) ans++;
            }
            dp[a][b] = ans;
        }
    }

    return dp;
}

vector<vector<int>> compute_difference_table(const vector<vector<bool>>& s_box) {
    const int SIZE = 1 << 4; 
    vector<vector<int>> diff_table(SIZE, vector<int>(SIZE, 0));
    for (int x1 = 0; x1 < SIZE; ++x1) {
        for (int x2 = 0; x2 < SIZE; ++x2) {
            int delta_x = x1 ^ x2;
            int delta_y = (s_box[x1][0] << 3 | s_box[x1][1] << 2 | s_box[x1][2] << 1 | s_box[x1][3] << 0) ^ 
                          (s_box[x2][0] << 3 | s_box[x2][1] << 2 | s_box[x2][2] << 1 | s_box[x2][3] << 0);
            diff_table[delta_x][delta_y]++;
        }
    }
    return diff_table;
}

void print_table_int(const vector<vector<int>>& table) {
    for (const auto& row : table) {
        for (int value : row) {
            cout << setw(4) << value << " ";
        }
        cout << endl;
    }
}

void print_table_ll(const vector<vector<ll>>& table) {
    for (const auto& row : table) {
        for (ll value : row) {
            cout << setw(4) << value << " ";
        }
        cout << endl;
    }
}

void find_s_boxes() {
    vector<vector<bool>> inputs = {
        {0, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, {0, 0, 1, 1},
        {0, 1, 0, 0}, {0, 1, 0, 1}, {0, 1, 1, 0}, {0, 1, 1, 1},
        {1, 0, 0, 0}, {1, 0, 0, 1}, {1, 0, 1, 0}, {1, 0, 1, 1},
        {1, 1, 0, 0}, {1, 1, 0, 1}, {1, 1, 1, 0}, {1, 1, 1, 1}
    };
    ll count = 0;

    do {
        vector<vector<bool>> perm(inputs);
        if (check_dep(perm)) {
            count++;
            cout << "Super-dependent S-box " << count << ":" << endl;
            for (const auto& p : perm) {
                cout << "[" << p[0] << ", " << p[1] << ", " << p[2] << ", " << p[3] << "]" << endl;
            }

            auto lat = compute_LAT(perm);
            auto diff_table = compute_difference_table(perm);

            cout << "Linear Approximation Table (LAT):" << endl;
            print_table_ll(lat);
            cout << "\nDifference Table:" << endl;
            print_table_int(diff_table);
            cout << endl;
        }
    } while (next_permutation(inputs.begin(), inputs.end()));

    cout << "\nTotal number of super-dependent S-boxes for n=4: " << count << endl;
}

int main() {
    find_s_boxes();
    return 0;
}
